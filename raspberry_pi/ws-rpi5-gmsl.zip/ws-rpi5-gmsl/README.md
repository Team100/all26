# GMSL Driver Deployment for Raspberry Pi 5

This repository contains kernel modules, device tree overlays, and utility scripts for testing GMSL cameras on Raspberry Pi 5.

---

## Table of Contents

- [GMSL Driver Deployment for Raspberry Pi 5](#gmsl-driver-deployment-for-raspberry-pi-5)
  - [Table of Contents](#table-of-contents)
  - [Requirements](#requirements)
  - [Installation](#installation)
  - [Usage](#usage)
    - [1. Using ISX031-GMSL-Camera-A / ISX031-GMSL-Camera-B Camera](#1-using-isx031-gmsl-camera-a--isx031-gmsl-camera-b-camera)
    - [2. Using GMSL-2MP-Camera-A Camera](#2-using-gmsl-2mp-camera-a-camera)
    - [3. Using GMSL-1MP-Camera-A Camera](#3-using-gmsl-1mp-camera-a-camera)
    - [4. Using GMSL-1MP-Dual-Camera-A Camera](#4-using-gmsl-1mp-dual-camera-a-camera)
    - [5. Using GMSL-3MP-Camera-A Camera](#5-using-gmsl-3mp-camera-a-camera)
    - [6. Using different cameras on CAM0 and CAM1](#6-using-different-cameras-on-cam0-and-cam1)
  - [Reference Images](#reference-images)
  - [Notes](#notes)
  - [Author](#author)

---

## Requirements

- Raspberry Pi 5 with Raspberry Pi OS (64-bit).  
- `sudo` privileges.  
- Enough free space in `/boot` for kernel image and overlays.  
- The Raspberry Pi must be running the official Raspberry Pi OS image:  
   `2025-05-13-raspios-bookworm-arm64.img.xz`
   `2026-06-18-raspios-trixie-arm64.img.xz`
   `2026-10-06-raspios-trixie-arm64.img.xz`

---

## Installation

1. Place folder "ws-rpi5-gmsl" in Raspberry Pi 5.

2. Add executable permissions to scripts:
   ```bash
   chmod a+x rpi5_gmsl_driver_install.sh
   ```

3. Run the deployment script:
   ```bash
   ./rpi5_gmsl_driver_install.sh
   ```

4. Install the GStreamer tools package:
   ```bash
   sudo apt update
   sudo apt install gstreamer1.0-tools
   ```
---

## Usage

### 1. Using ISX031-GMSL-Camera-A / ISX031-GMSL-Camera-B Camera

The Camera supports both single-link and dual-link operation.

1. Add the appropriate `dtoverlay` to `/boot/firmware/config.txt`:

- For single-link (either Link A or Link B, automatically detected):
```
dtoverlay=isx031-gmsl-camera-a,sensor-type=ISX031C_GMSL2F_1CH
```
- For dual-link:
```
dtoverlay=isx031-gmsl-camera-a,sensor-type=ISX031C_GMSL2F_2CH
```

2. If using the Raspberry Pi 5 `CAM0` interface, add the `cam0` parameter:
```
dtoverlay=isx031-gmsl-camera-a,sensor-type=ISX031C_GMSL2F_1CH,cam0
dtoverlay=isx031-gmsl-camera-a,sensor-type=ISX031C_GMSL2F_2CH,cam0
```

3. The default i2c address of the deserializer is 0x48(0x90>>1). If you need to modify the address of the deserializer, add the `dser-addr` parameter:
```
dtoverlay=isx031-gmsl-camera-a,sensor-type=ISX031C_GMSL2F_1CH,dser-addr=0x4a
dtoverlay=isx031-gmsl-camera-a,sensor-type=ISX031C_GMSL2F_2CH,dser-addr=0x4a
```

4. Reboot the Raspberry Pi 5.

5. Use the script `ws_camera_preview.sh` to preview the camera:

- Connected to `CAM1`, dual-camera:
```bash
ws_camera_preview.sh --csi1 ISX031-GMSL-Camera-A:2ch
```
- Connected to `CAM1`, single-camera:
```bash
ws_camera_preview.sh --csi1 ISX031-GMSL-Camera-A:1ch
```
- Connected to `CAM0`, dual-camera:
```bash
ws_camera_preview.sh --csi0 ISX031-GMSL-Camera-A:2ch
```
- Connected to `CAM0`, single-camera:
```bash
ws_camera_preview.sh --csi0 ISX031-GMSL-Camera-A:1ch
```

### 2. Using GMSL-2MP-Camera-A Camera

The Camera supports both single-link and dual-link operation.

1. Add the appropriate `dtoverlay` to `/boot/firmware/config.txt`:

- For single-link (either Link A or Link B, automatically detected):
```
dtoverlay=gmsl-2mp-camera-a,sensor-type=GMSL_1CH
```
- For dual-link:
```
dtoverlay=gmsl-2mp-camera-a,sensor-type=GMSL_2CH
```

2. If using the Raspberry Pi 5 `CAM0` interface, add the `cam0` parameter:
```
dtoverlay=gmsl-2mp-camera-a,sensor-type=GMSL_1CH,cam0
dtoverlay=gmsl-2mp-camera-a,sensor-type=GMSL_2CH,cam0
```

3. The default i2c address of the deserializer is 0x48(0x90>>1). If you need to modify the address of the deserializer, add the `dser-addr` parameter:
```
dtoverlay=gmsl-2mp-camera-a,sensor-type=GMSL_1CH,dser-addr=0x4a
dtoverlay=gmsl-2mp-camera-a,sensor-type=GMSL_2CH,dser-addr=0x4a
```

4. Reboot the Raspberry Pi 5.

5. Use the script `ws_camera_preview.sh` to preview the camera:

- Connected to `CAM1`, dual-camera:
```bash
ws_camera_preview.sh --csi1 GMSL-2MP-Camera-A:2ch
```
- Connected to `CAM1`, single-camera:
```bash
ws_camera_preview.sh --csi1 GMSL-2MP-Camera-A:1ch
```
- Connected to `CAM0`, dual-camera:
```bash
ws_camera_preview.sh --csi0 GMSL-2MP-Camera-A:2ch
```
- Connected to `CAM0`, single-camera:
```bash
ws_camera_preview.sh --csi0 GMSL-2MP-Camera-A:1ch
```

### 3. Using GMSL-1MP-Camera-A Camera

The Camera supports both single-link and dual-link operation.

1. Add the appropriate `dtoverlay` to `/boot/firmware/config.txt`:

- For single-link (Link A or Link B, automatic link detection is not supported):
```
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_1CH_LINKA
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_1CH_LINKB
```
- For dual-link:
```
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_2CH
```

2. If using the Raspberry Pi 5 `CAM0` interface, add the `cam0` parameter:
```
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_1CH_LINKA,cam0
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_1CH_LINKB,cam0
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_2CH,cam0
```

3. The default i2c address of the deserializer is 0x48(0x90>>1). If you need to modify the address of the deserializer, add the `dser-addr` parameter:
```
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_1CH_LINKA,dser-addr=0x4a
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_1CH_LINKB,dser-addr=0x4a
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_2CH,dser-addr=0x4a
```

4. Reboot the Raspberry Pi 5.

5. Use the script `ws_camera_preview.sh` to preview the camera:

- Connected to `CAM1`, dual-camera:
```bash
ws_camera_preview.sh --csi1 GMSL-1MP-Camera-A:2ch
```
- Connected to `CAM1`, single-camera:
```bash
ws_camera_preview.sh --csi1 GMSL-1MP-Camera-A:1ch
```
- Connected to `CAM0`, dual-camera:
```bash
ws_camera_preview.sh --csi0 GMSL-1MP-Camera-A:2ch
```
- Connected to `CAM0`, single-camera:
```bash
ws_camera_preview.sh --csi0 GMSL-1MP-Camera-A:1ch
```

### 4. Using GMSL-1MP-Dual-Camera-A Camera

The Camera is a stereo camera. It has one GMSL link with two outputs, so only single-channel input is supported, and the left and right images are previewed at the same time.

1. Add the `dtoverlay` to `/boot/firmware/config.txt` (either Link A or Link B, automatically detected):
```
dtoverlay=gmsl-1mp-camera-da,sensor-type=GMSL_1CH_DUAL
```

2. If using the Raspberry Pi 5 `CAM0` interface, add the `cam0` parameter:
```
dtoverlay=gmsl-1mp-camera-da,sensor-type=GMSL_1CH_DUAL,cam0
```

3. The default i2c address of the deserializer is 0x48(0x90>>1). If you need to modify the address of the deserializer, add the `dser-addr` parameter:
```
dtoverlay=gmsl-1mp-camera-da,sensor-type=GMSL_1CH_DUAL,dser-addr=0x4a
```

4. Reboot the Raspberry Pi 5.

5. Use the script `ws_camera_preview.sh` to preview the camera. The preview parameter of this camera is `GMSL-1MP-Camera-DA`:

- Connected to `CAM1`:
```bash
ws_camera_preview.sh --csi1 GMSL-1MP-Camera-DA:1ch
```
- Connected to `CAM0`:
```bash
ws_camera_preview.sh --csi0 GMSL-1MP-Camera-DA:1ch
```

### 5. Using GMSL-3MP-Camera-A Camera

The Camera supports both single-link and dual-link operation.

1. Add the appropriate `dtoverlay` to `/boot/firmware/config.txt`:

- For single-link (either Link A or Link B, automatically detected):
```
dtoverlay=gmsl-3mp-camera-a,sensor-type=GMSL_1CH
```
- For dual-link:
```
dtoverlay=gmsl-3mp-camera-a,sensor-type=GMSL_2CH
```

2. If using the Raspberry Pi 5 `CAM0` interface, add the `cam0` parameter:
```
dtoverlay=gmsl-3mp-camera-a,sensor-type=GMSL_1CH,cam0
dtoverlay=gmsl-3mp-camera-a,sensor-type=GMSL_2CH,cam0
```

3. The default i2c address of the deserializer is 0x48(0x90>>1). If you need to modify the address of the deserializer, add the `dser-addr` parameter:
```
dtoverlay=gmsl-3mp-camera-a,sensor-type=GMSL_1CH,dser-addr=0x4a
dtoverlay=gmsl-3mp-camera-a,sensor-type=GMSL_2CH,dser-addr=0x4a
```

4. Reboot the Raspberry Pi 5.

5. Use the script `ws_camera_preview.sh` to preview the camera:

- Connected to `CAM1`, dual-camera:
```bash
ws_camera_preview.sh --csi1 GMSL-3MP-Camera-A:2ch
```
- Connected to `CAM1`, single-camera:
```bash
ws_camera_preview.sh --csi1 GMSL-3MP-Camera-A:1ch
```
- Connected to `CAM0`, dual-camera:
```bash
ws_camera_preview.sh --csi0 GMSL-3MP-Camera-A:2ch
```
- Connected to `CAM0`, single-camera:
```bash
ws_camera_preview.sh --csi0 GMSL-3MP-Camera-A:1ch
```

### 6. Using different cameras on CAM0 and CAM1

Add one `dtoverlay` line for each CSI interface. Use `cam0` only for `CAM0` / `csi0`.

Example: `CAM0` uses `GMSL-1MP-Camera-A`, and `CAM1` uses `ISX031-GMSL-Camera-A`:
```
dtoverlay=gmsl-1mp-camera-a,sensor-type=GMSL_2CH,cam0
dtoverlay=isx031-gmsl-camera-a,sensor-type=ISX031C_GMSL2F_2CH
```

Preview both CSI interfaces:
```bash
ws_camera_preview.sh --csi0 GMSL-1MP-Camera-A:2ch --csi1 ISX031-GMSL-Camera-A:2ch
```

---

## Reference Images

**Dip Switch Example**  
<img src="images/dip_switch_1.jpg" alt="Dip Switch Example" style="width:500px; box-shadow: 4px 4px 10px rgba(0,0,0,0.3);">

**GMSL Connection Diagram**  
<img src="images/gmsl_connection_1.jpg" alt="GMSL Connection" style="width:500px; box-shadow: 4px 4px 10px rgba(0,0,0,0.3);">
<img src="images/gmsl_connection_2.jpg" alt="GMSL Connection" style="width:500px; box-shadow: 4px 4px 10px rgba(0,0,0,0.3);">

---

## Notes
1. When connecting the deserializer to the Raspberry Pi 5 CSI interface, use the shortest cable possible, preferably a shielded one.

---

## Author
English：<https://www.waveshare.com/>  
Chinese：<https://www.waveshare.net/>


