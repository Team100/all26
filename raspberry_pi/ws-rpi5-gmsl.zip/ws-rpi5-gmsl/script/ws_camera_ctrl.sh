#!/bin/bash

set -e

csi0_device_path="/sys/devices/platform/axi/1000120000.pcie/1f00110000.csi"
csi1_device_path="/sys/devices/platform/axi/1000120000.pcie/1f00128000.csi"
WS_CAMERA_DEBUG="${WS_CAMERA_DEBUG:-0}"
WS_CAMERA_DRY_RUN="${WS_CAMERA_DRY_RUN:-0}"

usage() {
    printf '%s\n' \
        "Usage:" \
        "  ws_camera_ctrl.sh csi0|csi1 1ch|2ch WIDTH HEIGHT MEDIA_FMT [VIDEO_CH0] [VIDEO_CH2]" \
        "" \
        "Examples:" \
        "  ws_camera_ctrl.sh csi0 2ch 1280 960 UYVY8_1X16 /dev/video8 /dev/video10" \
        "  ws_camera_ctrl.sh csi1 1ch 1920 1536 UYVY8_1X16 /dev/video0 /dev/video2"
}

run_cmd() {
    if [ "$WS_CAMERA_DEBUG" = "1" ] || [ "$WS_CAMERA_DRY_RUN" = "1" ]; then
        printf '+'
        printf ' %q' "$@"
        printf '\n'
    fi

    if [ "$WS_CAMERA_DRY_RUN" = "1" ]; then
        return 0
    fi

    "$@"
}

get_media_num() {
    find "$1" -maxdepth 1 -type d | while read -r dir; do
        media_num=$(echo "$dir" | grep -o 'media[0-9]\+' | sed 's/media//')
        if [ "$media_num" ]; then
            echo "$media_num"
            break
        fi
    done
}

get_sensor_entity() {
    local media_dev="$1"

    media-ctl -d "$media_dev" -p |
    awk '
        /^- entity/      { ent=$0 }
        /subtype Sensor/ { print ent; exit }
    ' |
    sed -n 's/.*entity [0-9]\+: \(.*\) (.*/\1/p'
}

get_video_node() {
    local media_dev="$1"
    local entity_name="$2"

    media-ctl -d "$media_dev" -p |
    awk -v entity_name="$entity_name" '
        $0 ~ "^- entity [0-9]+: " entity_name " " { in_entity=1; next }
        in_entity && /^- entity/ { in_entity=0 }
        in_entity && /device node name/ {
            sub(/.*device node name[[:space:]]*/, "", $0)
            print
            exit
        }
    '
}

setup_one_csi() {
    local csi_channel="$1"
    local channel_flag="$2"
    local sensor_width="$3"
    local sensor_height="$4"
    local sensor_media_fmt="$5"
    local video_ch0="$6"
    local video_ch2="$7"
    local csi_device_path
    local media_num
    local sensor_entity

    case "$csi_channel" in
        csi0)
            csi_device_path="$csi0_device_path"
            ;;
        csi1)
            csi_device_path="$csi1_device_path"
            ;;
        *)
            echo "ERROR: unsupported CSI channel: $csi_channel" >&2
            usage >&2
            exit 1
            ;;
    esac

    case "$channel_flag" in
        1ch|2ch)
            ;;
        *)
            echo "ERROR: unsupported channel flag: $channel_flag" >&2
            usage >&2
            exit 1
            ;;
    esac

    media_num=$(get_media_num "$csi_device_path")
    if [ -z "$media_num" ]; then
        echo "ERROR: failed to find media device under $csi_device_path" >&2
        exit 1
    fi

    sensor_entity=$(get_sensor_entity "$media_num")
    if [ -z "$sensor_entity" ]; then
        echo "ERROR: failed to find sensor entity on media$media_num" >&2
        exit 1
    fi

    echo "[INFO] $csi_channel media$media_num sensor='$sensor_entity'"
    echo "[INFO] $csi_channel format=${sensor_media_fmt}/${sensor_width}x${sensor_height} channels=$channel_flag"

    if [ -z "$video_ch0" ]; then
        video_ch0=$(get_video_node "$media_num" "rp1-cfe-csi2_ch0")
    fi

    if [ -z "$video_ch2" ]; then
        video_ch2=$(get_video_node "$media_num" "rp1-cfe-csi2_ch2")
    fi

    if [ -z "$video_ch0" ]; then
        echo "ERROR: failed to find $csi_channel ch0 video node on media$media_num" >&2
        exit 1
    fi

    echo "[INFO] $csi_channel video ch0=$video_ch0 ch2=${video_ch2:-none}"

    run_cmd media-ctl -r -d "$media_num"

    run_cmd media-ctl -d "$media_num" -l "'csi2':4 -> 'rp1-cfe-csi2_ch0':0 [1]"
    run_cmd media-ctl -d "$media_num" -V "'csi2':0 [fmt:${sensor_media_fmt}/${sensor_width}x${sensor_height} field:none colorspace:smpte170m]"
    run_cmd media-ctl -d "$media_num" -V "'csi2':1 [fmt:${sensor_media_fmt}/${sensor_width}x${sensor_height} field:none colorspace:smpte170m]"
    run_cmd media-ctl -d "$media_num" -V "'csi2':2 [fmt:${sensor_media_fmt}/${sensor_width}x${sensor_height} field:none colorspace:smpte170m]"
    run_cmd media-ctl -d "$media_num" -V "'${sensor_entity}':0 [fmt:${sensor_media_fmt}/${sensor_width}x${sensor_height} field:none colorspace:smpte170m]"
    run_cmd v4l2-ctl --device="$video_ch0" --set-fmt-video=width="${sensor_width}",height="${sensor_height}",pixelformat=UYVY

    if [ "$channel_flag" = "2ch" ]; then
        if [ -z "$video_ch2" ]; then
            echo "ERROR: failed to find $csi_channel ch2 video node on media$media_num" >&2
            exit 1
        fi

        run_cmd media-ctl -d "$media_num" -l "'csi2':6 -> 'rp1-cfe-csi2_ch2':0 [1]"
        run_cmd media-ctl -d "$media_num" -V "'${sensor_entity}':2 [fmt:${sensor_media_fmt}/${sensor_width}x${sensor_height} field:none colorspace:smpte170m]"
        run_cmd v4l2-ctl --device="$video_ch2" --set-fmt-video=width="${sensor_width}",height="${sensor_height}",pixelformat=UYVY
    fi
}

if [ "$#" -lt 5 ] || [ "$#" -gt 7 ]; then
    echo "ERROR: invalid number of arguments: $#" >&2
    usage >&2
    exit 1
fi

csi_channel="$1"
channel_flag="$2"
sensor_width="$3"
sensor_height="$4"
sensor_media_fmt="$5"
video_ch0="${6:-}"
video_ch2="${7:-}"

setup_one_csi "$csi_channel" "$channel_flag" "$sensor_width" "$sensor_height" "$sensor_media_fmt" "$video_ch0" "$video_ch2"
