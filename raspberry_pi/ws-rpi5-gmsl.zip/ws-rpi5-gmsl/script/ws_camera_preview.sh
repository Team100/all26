#!/bin/bash

set -e

gst_pids=()
script_path="${BASH_SOURCE[0]}"
case "$script_path" in
    */*)
        script_dir="${script_path%/*}"
        script_dir=$(CDPATH= cd -- "$script_dir" && pwd)
        ;;
    *)
        script_dir=$(pwd)
        ;;
esac
ctrl_script="$script_dir/ws_camera_ctrl.sh"
csi0_device_path="/sys/devices/platform/axi/1000120000.pcie/1f00110000.csi"
csi1_device_path="/sys/devices/platform/axi/1000120000.pcie/1f00128000.csi"
WS_CAMERA_DEBUG="${WS_CAMERA_DEBUG:-0}"
WS_CAMERA_DRY_RUN="${WS_CAMERA_DRY_RUN:-0}"

if [ -f "$ctrl_script" ]; then
    ctrl_cmd=(bash "$ctrl_script")
else
    ctrl_cmd=(ws_camera_ctrl.sh)
fi

usage() {
    printf '%s\n' \
        "Usage:" \
        "  ws_camera_preview.sh --csi0 SENSOR:1ch|2ch [--csi1 SENSOR:1ch|2ch]" \
        "  ws_camera_preview.sh --csi1 SENSOR:1ch|2ch" \
        "" \
        "Examples:" \
        "  ws_camera_preview.sh --csi0 GMSL-1MP-Camera-A:2ch" \
        "  ws_camera_preview.sh --csi1 ISX031-GMSL-Camera-A:1ch" \
        "  ws_camera_preview.sh --csi1 GMSL-1MP-Camera-DA:1ch" \
        "  ws_camera_preview.sh --csi0 GMSL-1MP-Camera-A:2ch --csi1 ISX031-GMSL-Camera-A:2ch" \
        "" \
        "Supported sensors:" \
        "  ISX031-GMSL-Camera-A" \
        "  ISX031-GMSL-Camera-B" \
        "  GMSL-2MP-Camera-A" \
        "  GMSL-1MP-Camera-A" \
        "  GMSL-1MP-Camera-DA (1ch only, dual output / stereo)" \
        "  GMSL-3MP-Camera-A"
}

run_cmd() {
    if [ "$WS_CAMERA_DEBUG" = "1" ] || [ "$WS_CAMERA_DRY_RUN" = "1" ]; then
        printf '+'
        printf ' %q' "$@"
        printf ' &\n'
    fi

    if [ "$WS_CAMERA_DRY_RUN" = "1" ]; then
        return 0
    fi

    exec "$@"
}

set_sensor_params() {
    local sensor_name="$1"

    sensor_dual_output=0
    sensor_framerate=30/1

    case "$sensor_name" in
        ISX031-GMSL-Camera-A)
            sensor_width=1920
            sensor_height=1536
            sensor_media_fmt=UYVY8_1X16
            gst_video_fmt=UYVY
            preview_width=640
            preview_height=512
            ;;
        ISX031-GMSL-Camera-B)
            sensor_width=1920
            sensor_height=1536
            sensor_media_fmt=UYVY8_1X16
            gst_video_fmt=UYVY
            preview_width=640
            preview_height=512
            ;;
        GMSL-2MP-Camera-A)
            sensor_width=1920
            sensor_height=1080
            sensor_media_fmt=UYVY8_1X16
            gst_video_fmt=UYVY
            preview_width=640
            preview_height=360
            ;;
        GMSL-1MP-Camera-A)
            sensor_width=1280
            sensor_height=960
            sensor_media_fmt=UYVY8_1X16
            gst_video_fmt=UYVY
            preview_width=640
            preview_height=480
            ;;
        GMSL-1MP-Camera-DA)
            sensor_width=1280
            sensor_height=800
            sensor_media_fmt=UYVY8_1X16
            gst_video_fmt=UYVY
            preview_width=640
            preview_height=400
            sensor_dual_output=1
            sensor_framerate=60/1
            ;;
        GMSL-3MP-Camera-A)
            sensor_width=1920
            sensor_height=1536
            sensor_media_fmt=UYVY8_1X16
            gst_video_fmt=UYVY
            preview_width=640
            preview_height=512
            ;;
        *)
            echo "ERROR: unsupported sensor type: '$sensor_name'" >&2
            usage >&2
            return 1
            ;;
    esac
}

parse_csi_value() {
    local csi_name="$1"
    local value="$2"
    local sensor="${value%:*}"
    local channel="${value##*:}"

    if [ -z "$sensor" ] || [ "$sensor" = "$value" ]; then
        echo "ERROR: $csi_name value must be SENSOR:1ch or SENSOR:2ch" >&2
        usage >&2
        exit 1
    fi

    case "$channel" in
        1ch|2ch)
            ;;
        *)
            echo "ERROR: $csi_name channel must be 1ch or 2ch: '$channel'" >&2
            usage >&2
            exit 1
            ;;
    esac

    set_sensor_params "$sensor" || exit 1

    # 双目对外只认 1ch，但驱动出两路图像，内部数据通路按 2ch 走。
    if [ "$sensor_dual_output" = "1" ]; then
        if [ "$channel" != "1ch" ]; then
            echo "ERROR: $sensor only supports 1ch: '$value'" >&2
            usage >&2
            exit 1
        fi
        channel=2ch
    fi

    case "$csi_name" in
        csi0)
            csi0_sensor="$sensor"
            csi0_channel="$channel"
            ;;
        csi1)
            csi1_sensor="$sensor"
            csi1_channel="$channel"
            ;;
    esac
}

parse_args() {
    if [ "$#" -eq 0 ]; then
        usage >&2
        exit 1
    fi

    while [ "$#" -gt 0 ]; do
        case "$1" in
            --csi0)
                if [ "$#" -lt 2 ]; then
                    echo "ERROR: --csi0 requires SENSOR:1ch or SENSOR:2ch" >&2
                    usage >&2
                    exit 1
                fi
                parse_csi_value csi0 "$2"
                shift 2
                ;;
            --csi1)
                if [ "$#" -lt 2 ]; then
                    echo "ERROR: --csi1 requires SENSOR:1ch or SENSOR:2ch" >&2
                    usage >&2
                    exit 1
                fi
                parse_csi_value csi1 "$2"
                shift 2
                ;;
            --help|-h)
                usage
                exit 0
                ;;
            --debug)
                # 打印并执行 media-ctl/v4l2-ctl/gst-launch 命令，方便确认 media/video 节点和分辨率。
                WS_CAMERA_DEBUG=1
                shift
                ;;
            --dry-run)
                # 只打印命令，不真正执行 media-ctl/v4l2-ctl/gst-launch。
                WS_CAMERA_DRY_RUN=1
                WS_CAMERA_DEBUG=1
                shift
                ;;
            *)
                echo "ERROR: old positional arguments are no longer supported: '$1'" >&2
                usage >&2
                exit 1
                ;;
        esac
    done

    if [ -z "$csi0_sensor" ] && [ -z "$csi1_sensor" ]; then
        echo "ERROR: at least one of --csi0 or --csi1 must be set" >&2
        usage >&2
        exit 1
    fi
}

get_media_num() {
    find "$1" -maxdepth 1 -type d | while read -r dir; do
        media_num=$(echo "$dir" | grep -o 'media[0-9]\+' | sed 's/media//')
        if [ "$media_num" ]; then
            echo "$media_num"
            break
        fi
    done
}

get_video_node() {
    local media_dev="$1"
    local entity_name="$2"

    media-ctl -d "$media_dev" -p |
    awk -v entity_name="$entity_name" '
        $0 ~ "^- entity [0-9]+: " entity_name " " { in_entity=1; next }
        in_entity && /^- entity/ { in_entity=0 }
        in_entity && /device node name/ {
            sub(/.*device node name[[:space:]]*/, "", $0)
            print
            exit
        }
    '
}

get_video_devices() {
    local csi_name="$1"
    local csi_device_path
    local media_num

    case "$csi_name" in
        csi0)
            csi_device_path="$csi0_device_path"
            ;;
        csi1)
            csi_device_path="$csi1_device_path"
            ;;
        *)
            echo "ERROR: unsupported CSI channel: $csi_name" >&2
            exit 1
            ;;
    esac

    media_num=$(get_media_num "$csi_device_path")
    if [ -z "$media_num" ]; then
        echo "ERROR: failed to find media device under $csi_device_path" >&2
        exit 1
    fi

    video_ch0=$(get_video_node "$media_num" "rp1-cfe-csi2_ch0")
    video_ch2=$(get_video_node "$media_num" "rp1-cfe-csi2_ch2")

    if [ -z "$video_ch0" ]; then
        echo "ERROR: failed to find $csi_name ch0 video node on media$media_num" >&2
        exit 1
    fi
}

configure_one_csi() {
    local csi_name="$1"
    local sensor="$2"
    local channel="$3"

    set_sensor_params "$sensor" || exit 1
    get_video_devices "$csi_name"

    echo "[INFO] configure $csi_name sensor=$sensor channel=$channel video0=$video_ch0 video2=$video_ch2"
    WS_CAMERA_DEBUG="$WS_CAMERA_DEBUG" WS_CAMERA_DRY_RUN="$WS_CAMERA_DRY_RUN" \
        "${ctrl_cmd[@]}" "$csi_name" "$channel" "$sensor_width" "$sensor_height" "$sensor_media_fmt" "$video_ch0" "$video_ch2"
}

preview_one_csi() {
    local csi_name="$1"
    local sensor="$2"
    local channel="$3"

    set_sensor_params "$sensor" || exit 1
    get_video_devices "$csi_name"

    echo "[INFO] preview $csi_name ch0 from $video_ch0 scale=${preview_width}x${preview_height}"
    run_cmd gst-launch-1.0 v4l2src device="${video_ch0}" ! "video/x-raw,format=${gst_video_fmt},width=${sensor_width},height=${sensor_height},framerate=${sensor_framerate}" ! videoconvert ! videoscale ! "video/x-raw,width=${preview_width},height=${preview_height}" ! fpsdisplaysink video-sink=xvimagesink sync=false &
    pid=$!
    gst_pids+=("$pid")

    if [ "$channel" = "2ch" ]; then
        if [ -z "$video_ch2" ]; then
            echo "ERROR: failed to find $csi_name ch2 video node" >&2
            exit 1
        fi

        sleep 0.5

        echo "[INFO] preview $csi_name ch2 from $video_ch2 scale=${preview_width}x${preview_height}"
        run_cmd gst-launch-1.0 v4l2src device="${video_ch2}" ! "video/x-raw,format=${gst_video_fmt},width=${sensor_width},height=${sensor_height},framerate=${sensor_framerate}" ! videoconvert ! videoscale ! "video/x-raw,width=${preview_width},height=${preview_height}" ! fpsdisplaysink video-sink=xvimagesink sync=false &
        pid=$!
        gst_pids+=("$pid")
    fi
}

cleanup() {
    echo "Cleaning up gst-launch processes..."
    for pid in "${gst_pids[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
            echo "Killing process $pid"
            kill "$pid"
        fi
    done

    # 等 gst 真正退出，确保 /dev/video* 已经释放
    for pid in "${gst_pids[@]}"; do
        wait "$pid" 2>/dev/null || true
    done

    exit 0
}

trap cleanup SIGINT SIGTERM

csi0_sensor=""
csi0_channel=""
csi1_sensor=""
csi1_channel=""

parse_args "$@"

if [ -n "$csi0_sensor" ]; then
    configure_one_csi csi0 "$csi0_sensor" "$csi0_channel"
fi

if [ -n "$csi1_sensor" ]; then
    configure_one_csi csi1 "$csi1_sensor" "$csi1_channel"
fi

if [ -n "$csi0_sensor" ]; then
    preview_one_csi csi0 "$csi0_sensor" "$csi0_channel"
fi

if [ -n "$csi1_sensor" ]; then
    preview_one_csi csi1 "$csi1_sensor" "$csi1_channel"
fi

wait
